import FullMarkPlatform from "@/components/full-mark-platform";

export default function Page() {
  return <FullMarkPlatform />;
}
