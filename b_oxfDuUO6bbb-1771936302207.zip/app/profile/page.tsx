import StudentProfile from "@/components/student-profile";

export default function ProfilePage() {
  return <StudentProfile />;
}
